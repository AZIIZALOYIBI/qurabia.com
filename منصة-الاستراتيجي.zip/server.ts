import express from "express";
import { createServer as createViteServer } from "vite";
import { AUTDIESecurityFunction } from "./src/lib/QuantumCrypto";
import { AlUtaibiEquationV2 } from "./src/lib/AlUtaibiEquationV2";

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Middleware to parse JSON bodies
  app.use(express.json());

  const patientsData = [
    {
      id: "PT-BRCA1",
      name: "حالة 1: طفرة BRCA1 (سرطان الثدي)",
      genomicData: {
        sequence: "ATGGATTTATCTGCTCTTCGCGTTGAAGAAGTACAAAATGTCATTAATGCTATGCAGAAAATCTTAGAGTGTCCCATCTGTCTGGAGTTGATCAAGGAACCTGTCTCCACAAAGTGTGACCACATATTTTGCAAATTTTGCATGCTGAAACTTCTCAACCAGAAGAAAGGGCCTTCACAGTGTCCTTTATGTAAGAATGATATAACCAAAAGGAGCCTACAAGAAAGTACGAGATTTAGTCAACTTGTTGAAGAGCTATTGAAAATCATTTGTGCTTTTCAGCTTGACACAGGTTTGGAGTATGCAAACAGCTATAATTTTGCAAAAAAGGAAAATAACTCTCCTGAACATCTAAAAGATGAAGTTTCTATCATCCAAAGTATGGGCTACAGAAACCGTGCCAAAAGACTTCTACAGAGTGAACCCGAAAATCCTTCCTT"
      },
      clinicalData: {
        symptoms: "المريضة أنثى، 42 عاماً. تشتكي من وجود كتلة صلبة غير مؤلمة في الثدي الأيمن تم اكتشافها أثناء الفحص الذاتي. أظهر الماموجرام (Mammogram) والموجات فوق الصوتية وجود كتلة غير منتظمة الحواف بحجم 1.8 سم. يوجد تاريخ عائلي قوي للإصابة بسرطان الثدي والمبيض (الأم والخالة)."
      }
    },
    {
      id: "PT-TP53",
      name: "حالة 2: طفرة TP53 (سرطان الرئة)",
      genomicData: {
        sequence: "ATGGAGGAGCCGCAGTCAGATCCTAGCGTCGAGCCCCCTCTGAGTCAGGAAACATTTTCAGACCTATGGAAACTACTTCCTGAAAACAACGTTCTGTCCCCCTTGCCGTCCCAAGCAATGGATGATTTGATGCTGTCCCCGGACGATATTGAACAATGGTTCACTGAAGACCCAGGTCCAGATGAAGCTCCCAGAATGCCAGAGGCTGCTCCCCCCGTGGCCCCTGCACCAGCAGCTCCTACACCGGCGGCCCCTGCACCAGCCCCCTCCTGGCCCCTGTCATCTTCTGTCCCTTCCCAGAAAACCTACCAGGGCAGCTACGGTTTCCGTCTGGGCTTCTTGCATTCTGGGACAGCCAAGTCTGTGACTTGCACGTACTCCCCTGCCCTCAACAAGATGTTTTGCCAACTGGCCAAGACCTGCCCTGTGCAGCTGTGGGTTGATTCCACACCCCCGCCCGGCACCCGCGTCCGCGCCATGGCCATCTACAAGCAGTCACAGCACATGACGGAGGTTGTGAGGCGCTGCCCCCACCATGAGCGCTGCTCAGATAGCGATGGTCTGGCCCCTCCTCAGCATCTTATCCGAGTGGAAGGAAATTTGCGTGTGGAGTATTTGGATGACAGAAACACTTTTCGACATAGTGTGGTGGTGCCCTATGAGCCGCCTGAGGTTGGCTCTGACTGTACCACCATCCACTACAACTACATGTGTAACAGTTCCTGCATGGGCGGCATGAACCGGAGGCCCATCCTCACCATCATCACACTGGAAGACTCCAGTGGTAATCTACTGGGACGGAACAGCTTTGAGGTGCGTGTTTGTGCCTGTCCTGGGAGAGACCGGCGCACAGAGGAAGAGAATCTCCGCAAGAAAGGGGAGCCTCACCACGAGCTGCCCCCAGGGAGCACTAAGCGAGCACTGCCCAACAACACCAGCTCCTCTCCCCAGCCAAAGAAGAAACCACTGGATGGAGAATATTTCACCCTTCAGATCCGTGGGCGTGAGCGCTTCGAGATGTTCCGAGAGCTGAATGAGGCCTTGGAACTCAAGGATGCCCAGGCTGGGAAGGAGCCAGGGGGGAGCAGGGCTCACTCCAGCCACCTGAAGTCCAAAAAGGGTCAGTCTACCTCCCGCCATAAAAAACTCATGTTCAAGACAGAAGGGCCTGACTCAGACTGA"
      },
      clinicalData: {
        symptoms: "المريضة أنثى، 52 عاماً. تعاني من سعال جاف مستمر منذ 3 أشهر مع فقدان غير مبرر للوزن (حوالي 5 كجم). أظهرت الأشعة المقطعية (CT scan) للصدر وجود كتلة غير منتظمة بحجم 2.5 سم في الفص العلوي للرئة اليمنى مع تضخم في العقد الليمفاوية المنصفية. لا يوجد تاريخ للتدخين."
      }
    },
    {
      id: "PT-APOE",
      name: "حالة 3: طفرة APOE-e4 (ألزهايمر)",
      genomicData: {
        sequence: "ATGAAGGTTCTGTGGGCTGCGTTGCTGGTCACATTCCTGGCAGGATGCCAGGCCAAGGTGGAGCAAGCGGTGGAGACAGAGCCGGAGCCCGAGCTGCGCCAGCAGACCGAGTGGCAGAGCGGCCAGCGCTGGGAACTGGCACTGGGTCGCTTTTGGGATTACCTGCGCTGGGTGCAGACACTGTCTGAGCAGGTGCAGGAGGAGCTGCTCAGCTCCCAGGTCACCCAGGAACTGAGGGCGCTGATGGACGAGACCATGAAGGAGTTGAAGGCCTACAAATCGGAACTGGAGGAACAACTGACCCCGGTGGCGGAGGAGACGCGGGCACGGCTGTCCAAGGAGCTGCAGGCGGCGCAGGCCCGGCTGGGCGCGGACATGGAGGACGTGTGCGGCCGCCTGGTGCAGTACCGCGGCGAGGTGCAGGCCATGCTCGGCCAGAGCACCGAGGAGCTGCGGGTGCGCCTCGCCTCCCACCTGCGCAAGCTGCGTAAGCGGCTCCTCCGCGATGCCGATGACCTGCAGAAGCGCCTGGCAGTGTACCAGGCCGGGGCCCGCGAGGGCGCCGAGCGCGGCCTCAGCGCCATCCGCGAGCGCCTGGGGCCCCTGGTGGAACAGGGCCGCGTGCGGGCCGCCACTGTGGGCTCCCTGGCCGGCCAGCCGCTACAGGAGCGGGCCCAGGCCTGGGGCGAGCGGCTGCGCGCGCGGATGGAGGAGATGGGCAGCCGGACCCGCGACCGCCTGGACGAGGTGAAGGAGCAGGTGGCGGAGGTGCGCGCCAAGCTGGAGGAGCAGGCCCAGCAGATACGCCTGCAGGCCGAGGCCTTCCAGGCCCGCCTCAAGAGCTGGTTCGAGCCCCTGGTGGAAGACATGCAGCGCCAGTGGGCCGGGCTGGTGGAGAAGGTGCAGGCTGCCGTGGGCACCAGCGCCGCCCCTGTGCCCAGCGACAATCACTGA"
      },
      clinicalData: {
        symptoms: "المريض ذكر، 68 عاماً. يعاني من تدهور تدريجي في الذاكرة قصيرة المدى على مدار العامين الماضيين. يجد صعوبة متزايدة في تذكر الأسماء والمواعيد، ويضيع أحياناً في الأماكن المألوفة. أظهر التصوير بالرنين المغناطيسي (MRI) للدماغ ضموراً ملحوظاً في الحصين (Hippocampus) والقشرة الصدغية الجدارية، مع توسع في البطينات الدماغية."
      }
    }
  ];

  const crypto = new AUTDIESecurityFunction();
  const alUtaibiV2 = new AlUtaibiEquationV2();

  // API routes FIRST
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok" });
  });

  // AUTDIE Security Endpoint
  app.post("/api/autdie", (req, res) => {
    const { kappa, lam } = req.body;
    
    // Default values if not provided
    const k = kappa !== undefined ? Number(kappa) : Math.PI / 4;
    const l = lam !== undefined ? Number(lam) : 1.0;
    
    // Compute the security metrics using the backend logic
    const result = crypto.compute(0, k, l);
    
    // Send the result back to the client
    res.json(result);
  });

  // Al-Utaibi Equation v2.0 Endpoint
  app.post("/api/al-utaibi-v2", (req, res) => {
    const { r, rho_dm, rho_de } = req.body;
    
    try {
      const result = alUtaibiV2.compute_total_energy(
        r !== undefined ? Number(r) : 1.616e-35,
        rho_dm !== undefined ? Number(rho_dm) : 1.8e10,
        rho_de !== undefined ? Number(rho_de) : 1e-10
      );
      res.json(result);
    } catch (error) {
      console.error("Error computing Al-Utaibi v2.0:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Get patients list
  app.get("/api/medical/patients", (req, res) => {
    res.json(patientsData.map(p => ({ id: p.id, name: p.name })));
  });

  // Sanger Institute Genomic Database Mock
  app.get("/api/medical/sanger-genomic", (req, res) => {
    const authHeader = req.headers.authorization;
    if (authHeader !== "Bearer SANGER_SECURE_TOKEN_2026") {
        return res.status(401).json({ error: "Unauthorized: Invalid or missing Sanger Institute secure token." });
    }
    const patientId = req.query.patientId;
    const patient = patientsData.find(p => p.id === patientId) || patientsData[0];
    setTimeout(() => {
      res.json({
        source: "Sanger Institute",
        dataset: "Human Genome Project v38",
        sequence: patient.genomicData.sequence
      });
    }, 800);
  });

  // Johns Hopkins Clinical Database Mock
  app.get("/api/medical/hopkins-clinical", (req, res) => {
    const authHeader = req.headers.authorization;
    if (authHeader !== "Bearer HOPKINS_SECURE_TOKEN_2026") {
        return res.status(401).json({ error: "Unauthorized: Invalid or missing Johns Hopkins secure token." });
    }
    const patientId = req.query.patientId;
    const patient = patientsData.find(p => p.id === patientId) || patientsData[0];
    setTimeout(() => {
      res.json({
        source: "Johns Hopkins Hospital",
        patientId: patient.id,
        symptoms: patient.clinicalData.symptoms
      });
    }, 1000);
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    // Serve static files in production
    app.use(express.static("dist"));
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
