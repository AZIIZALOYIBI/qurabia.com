/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useCallback } from 'react';
import { AlOtaibiPlanckModule } from './components/AlOtaibiPlanckModule';
import { QuantumDrugDiscovery } from './components/QuantumDrugDiscovery';
import { QuantumCryptoModule } from './components/QuantumCryptoModule';
import { TopologicalQECVisualizer } from './components/TopologicalQECVisualizer';
import { QuantumNeuralNetworkModule } from './components/QuantumNeuralNetworkModule';
import { AGISecurityIntegration } from './components/AGISecurityIntegration';
import { VirtualLogsTerminal } from './components/VirtualLogsTerminal';
import { AlUtaibiV2Module } from './components/AlUtaibiV2Module';
import { ConsciousMedicalModule } from './components/ConsciousMedicalModule';
import { GroverSearchModule } from './components/GroverSearchModule';
import { SovereignDashboard } from './components/SovereignDashboard';
import { Cpu, Network, Zap, Shield } from 'lucide-react';
import { SecurityResult } from './lib/QuantumCrypto';

import { ToastProvider } from './components/Toast';

export default function App() {
  const [cryptoKappa, setCryptoKappa] = useState<number>(Math.PI / 4);
  const [cryptoLam, setCryptoLam] = useState<number>(1.0);
  const [cryptoResult, setCryptoResult] = useState<SecurityResult | null>(null);

  const handleUpdateParameters = useCallback((newKappa: number, newLam: number) => {
    setCryptoKappa(newKappa);
    setCryptoLam(newLam);
  }, []);

  return (
    <ToastProvider>
      <div className="min-h-screen bg-transparent text-slate-200 font-sans selection:bg-emerald-500/30 tech-grid relative" dir="rtl">
      {/* Ambient Background Effects */}
      <div className="fixed inset-0 z-[-1] pointer-events-none overflow-hidden bg-gradient-to-br from-[#030508] via-[#0a0d14] to-[#030508]">
        <div className="absolute top-[-20%] left-[-10%] w-[50%] h-[50%] bg-emerald-900/10 blur-[120px] rounded-full mix-blend-screen"></div>
        <div className="absolute bottom-[-20%] right-[-10%] w-[50%] h-[50%] bg-blue-900/10 blur-[120px] rounded-full mix-blend-screen"></div>
      </div>

      {/* Header */}
      <header className="border-b border-white/5 bg-[#0a0d14]/60 backdrop-blur-xl sticky top-0 z-50">
        <div className="max-w-[1600px] mx-auto px-6 h-20 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-emerald-600 to-teal-900 flex items-center justify-center shadow-[0_0_30px_rgba(16,185,129,0.3)] border border-emerald-500/40 relative overflow-hidden">
              <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-20 mix-blend-overlay"></div>
              <Shield size={24} className="text-white relative z-10" />
            </div>
            <div>
              <h1 className="text-3xl font-bold tracking-tight text-white mb-0.5 font-serif">
                نظام السوبر الكمي الموحد
              </h1>
              <p className="text-[11px] font-mono text-emerald-400 uppercase tracking-[0.2em] glow-text-emerald">
                معادلة العتيبي الموحدة ومستقبل الحوسبة السيادية
              </p>
            </div>
          </div>
          <div className="flex items-center gap-6 text-sm font-mono text-slate-400">
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-md bg-white/5 border border-white/10">
              <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse-slow shadow-[0_0_10px_rgba(16,185,129,0.8)]"></div>
              <span className="text-emerald-400">QPU Active</span>
            </div>
            <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-md bg-white/5 border border-white/10">
              <Cpu size={14} className="text-blue-400" />
              <span className="text-blue-400">1000+ Logical Qubits</span>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-[1600px] mx-auto px-6 py-8 relative z-10">
        <div className="mb-10 flex justify-between items-end border-b border-white/10 pb-6">
          <div>
            <h2 className="text-4xl font-light text-white mb-3 font-serif tracking-wide">لوحة التحكم السيادية</h2>
            <p className="text-slate-400 max-w-3xl text-sm leading-relaxed font-mono">
              نظام تشغيل متكامل للواقع الكمومي، مبني على أسس برمجية صلبة. يجسد معادلة العتيبي-بلانك ونظام AUTDIE في حوسبة الذكاء العام ذاتية التطور.
            </p>
          </div>
          <div className="text-right hidden md:block glass-panel p-4 rounded-xl border-r-2 border-r-emerald-500">
            <div className="text-xs text-slate-500 font-mono mb-1 uppercase tracking-widest">المطور المعماري</div>
            <div className="text-base text-emerald-400 font-semibold tracking-wide">د. عبد العزيز بن سلطان العتيبي</div>
            <div className="text-[10px] text-slate-500 mt-2 font-mono">© وزارة الداخلية - جميع الحقوق محفوظة</div>
          </div>
        </div>

        {/* Sovereign Metrics Dashboard */}
        <div className="mb-10">
          <SovereignDashboard />
        </div>

        {/* Grid Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* Row 1: Deep Backend - Al-Utaibi v2.0 */}
          <div className="lg:col-span-3 h-[400px] glass-panel rounded-2xl overflow-hidden">
            <AlUtaibiV2Module />
          </div>

          {/* Row 2: Conscious Medical Engine & Grover Search */}
          <div className="lg:col-span-3 min-h-[400px] glass-panel rounded-2xl overflow-hidden">
            <ConsciousMedicalModule />
          </div>
          <div className="lg:col-span-3 h-[450px] glass-panel rounded-2xl overflow-hidden">
            <GroverSearchModule />
          </div>

          {/* Row 3: Planck & Crypto */}
          <div className="lg:col-span-2 h-[500px] glass-panel rounded-2xl overflow-hidden">
            <AlOtaibiPlanckModule />
          </div>
          <div className="h-[500px] glass-panel rounded-2xl overflow-hidden">
            <QuantumCryptoModule 
              kappa={cryptoKappa} 
              lam={cryptoLam} 
              onKappaChange={setCryptoKappa} 
              onLamChange={setCryptoLam} 
              onResultUpdate={setCryptoResult} 
            />
          </div>

          {/* Row 4: AGI Integration & QNN */}
          <div className="h-[500px] glass-panel rounded-2xl overflow-hidden">
            <AGISecurityIntegration 
              currentKappa={cryptoKappa}
              currentLam={cryptoLam}
              currentSAUTDIE={cryptoResult?.S_AUTDIE || 0}
              currentQBER={cryptoResult?.QBER_AUTDIE || 0}
              onUpdateParameters={handleUpdateParameters}
            />
          </div>
          <div className="lg:col-span-2 h-[500px] glass-panel rounded-2xl overflow-hidden">
            <QuantumNeuralNetworkModule />
          </div>

          {/* Row 5: Topological QEC & Drug Discovery */}
          <div className="lg:col-span-1 h-[500px] glass-panel rounded-2xl overflow-hidden">
            <TopologicalQECVisualizer />
          </div>
          <div className="lg:col-span-2 h-[500px] glass-panel rounded-2xl overflow-hidden">
            <QuantumDrugDiscovery />
          </div>

          {/* Row 6: Virtual Execution Logs Terminal */}
          <div className="lg:col-span-3 h-[400px] glass-panel rounded-2xl overflow-hidden">
            <VirtualLogsTerminal />
          </div>

        </div>
      </main>
    </div>
    </ToastProvider>
  );
}
