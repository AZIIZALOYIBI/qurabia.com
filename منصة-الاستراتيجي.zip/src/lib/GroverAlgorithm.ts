export class GroverSimulator {
    size: number;
    targetIndex: number;
    amplitudes: number[];
    sum: number;
    
    constructor(size: number, targetIndex: number) {
        this.size = size;
        this.targetIndex = targetIndex;
        const initialAmp = 1 / Math.sqrt(size);
        this.amplitudes = new Array(size).fill(initialAmp);
        this.sum = initialAmp * size;
    }

    // الخطوة 1: الأوراكل (Oracle) يعكس إشارة العنصر المستهدف
    applyOracle() {
        if (this.targetIndex >= 0 && this.targetIndex < this.size) {
            this.amplitudes[this.targetIndex] *= -1;
            // تحديث المجموع بعد الانعكاس
            this.sum += 2 * this.amplitudes[this.targetIndex];
        }
    }

    // الخطوة 2: مؤثر الانتشار (Diffusion Operator) يعكس السعات حول المتوسط
    applyDiffusion() {
        const mean = this.sum / this.size;
        let newSum = 0;

        // الانعكاس حول المتوسط
        for (let i = 0; i < this.size; i++) {
            this.amplitudes[i] = (2 * mean) - this.amplitudes[i];
            newSum += this.amplitudes[i];
        }
        this.sum = newSum;
    }

    // تنفيذ خطوة واحدة كاملة من خوارزمية جروفر
    step() {
        this.applyOracle();
        this.applyDiffusion();
    }

    // الحصول على الاحتمالات الحالية (مربع السعة)
    getProbabilities(): number[] {
        return this.amplitudes.map(amp => amp * amp);
    }

    // العدد الأمثل للخطوات
    getOptimalSteps(): number {
        return Math.floor((Math.PI / 4) * Math.sqrt(this.size));
    }
}
