import React, { useState, useEffect } from 'react';
import { Shield, ShieldAlert, ShieldCheck, Lock, Server } from 'lucide-react';
import { SecurityResult } from '../lib/QuantumCrypto';
import { useToast } from './Toast';

interface QuantumCryptoModuleProps {
    kappa: number;
    lam: number;
    onKappaChange: (kappa: number) => void;
    onLamChange: (lam: number) => void;
    onResultUpdate: (result: SecurityResult | null) => void;
}

export const QuantumCryptoModule: React.FC<QuantumCryptoModuleProps> = ({
    kappa,
    lam,
    onKappaChange,
    onLamChange,
    onResultUpdate
}) => {
    const { showToast } = useToast();
    const [result, setResult] = useState<SecurityResult | null>(null);
    const [loading, setLoading] = useState<boolean>(false);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        const fetchSecurityMetrics = async () => {
            setLoading(true);
            setError(null);
            try {
                const response = await fetch('/api/autdie', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ kappa, lam }),
                });

                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }

                const data: SecurityResult = await response.json();
                setResult(data);
                onResultUpdate(data);
            } catch (e) {
                console.error("Failed to fetch from AUTDIE backend:", e);
                setError("فشل الاتصال بالخادم الخلفي (Backend)");
                showToast("فشل الاتصال بخادم التشفير الكمي.", "error");
                onResultUpdate(null);
            } finally {
                setLoading(false);
            }
        };

        fetchSecurityMetrics();
    }, [kappa, lam, onResultUpdate]);

    return (
        <div className="p-6 bg-transparent h-full flex flex-col relative overflow-hidden">
            {/* Background pattern */}
            <div className="absolute inset-0 opacity-5 pointer-events-none" style={{ backgroundImage: 'radial-gradient(#fff 1px, transparent 1px)', backgroundSize: '20px 20px' }}></div>
            
            <div className="relative z-10 mb-6 flex justify-between items-start">
                <div>
                    <h2 className="text-xl font-semibold text-white mb-1 font-sans">التشفير الكمي الموحد</h2>
                    <p className="text-sm text-slate-400 font-mono">AUTDIE Security Kernel (Backend API)</p>
                </div>
                <div className="flex items-center gap-2 text-xs font-mono bg-slate-800/80 px-3 py-1.5 rounded-full border border-white/10">
                    <Server size={14} className={loading ? "text-yellow-400 animate-pulse" : "text-emerald-400"} />
                    <span className={loading ? "text-yellow-400" : "text-emerald-400"}>
                        {loading ? "جاري الاتصال..." : "متصل بالخادم"}
                    </span>
                </div>
            </div>

            <div className="relative z-10 flex-grow flex flex-col justify-between">
                
                {error ? (
                    <div className="flex-grow flex items-center justify-center text-red-400 font-mono text-sm text-center">
                        {error}
                    </div>
                ) : (
                    <>
                        <div className="flex items-center justify-center mb-8">
                            <div className={`relative flex items-center justify-center w-32 h-32 rounded-full border-2 ${result?.secure ? 'border-emerald-500/30 bg-emerald-500/10' : 'border-red-500/30 bg-red-500/10'} transition-colors duration-500`}>
                                {result?.secure ? (
                                    <ShieldCheck size={64} className="text-emerald-400" />
                                ) : (
                                    <ShieldAlert size={64} className="text-red-400" />
                                )}
                                
                                {/* Orbiting element */}
                                <div className="absolute inset-0 rounded-full animate-[spin_4s_linear_infinite]" style={{ border: '1px dashed rgba(255,255,255,0.2)' }}>
                                    <div className={`absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 w-3 h-3 rounded-full ${result?.secure ? 'bg-emerald-400' : 'bg-red-400'} shadow-[0_0_10px_rgba(255,255,255,0.5)]`}></div>
                                </div>
                            </div>
                        </div>

                        <div className="grid grid-cols-2 gap-4 mb-6">
                            <div className="bg-black/40 p-4 rounded-lg border border-white/5 text-center">
                                <div className="text-[10px] font-mono text-slate-400 uppercase tracking-widest mb-2">مستوى الأمان (CRYSTALS-Kyber)</div>
                                <div className={`text-2xl font-mono ${result?.secure ? 'text-emerald-400' : 'text-red-400'}`}>
                                    {result?.S_AUTDIE.toFixed(4)}
                                </div>
                            </div>
                            <div className="bg-black/40 p-4 rounded-lg border border-white/5 text-center">
                                <div className="text-[10px] font-mono text-slate-400 uppercase tracking-widest mb-2">معدل الخطأ (E91 Protocol)</div>
                                <div className="text-2xl font-mono text-white">
                                    {(result?.QBER_AUTDIE ? result.QBER_AUTDIE * 100 : 0).toFixed(2)}%
                                </div>
                            </div>
                        </div>
                    </>
                )}

                <div className="space-y-4">
                    <div className="bg-slate-800/50 p-4 rounded-lg border border-white/5">
                        <div className="flex justify-between mb-2">
                            <label className="text-xs font-mono text-slate-400 uppercase tracking-wider">زاوية الاستقطاب (κ)</label>
                            <span className="text-xs font-mono text-white bg-slate-900 px-2 py-1 rounded">{(kappa / Math.PI).toFixed(2)}π</span>
                        </div>
                        <input 
                            type="range" min="0" max={Math.PI} step="0.01"
                            value={kappa} 
                            onChange={(e) => onKappaChange(Number(e.target.value))} 
                            className="w-full h-2 bg-slate-900 rounded-lg appearance-none cursor-pointer accent-emerald-500" 
                        />
                        <div className="flex justify-between mt-2 text-[10px] text-slate-500 font-mono">
                            <span>0</span>
                            <span>π/2</span>
                            <span>π</span>
                        </div>
                    </div>
                    
                    <div className="bg-amber-500/10 border border-amber-500/20 p-3 rounded-lg flex justify-between items-center">
                        <span className="text-xs text-amber-400 font-mono">McEliece Cryptosystem</span>
                        <span className="text-xs text-amber-200 font-mono bg-amber-500/20 px-2 py-1 rounded">512-bit</span>
                    </div>
                </div>
            </div>
        </div>
    );
};
