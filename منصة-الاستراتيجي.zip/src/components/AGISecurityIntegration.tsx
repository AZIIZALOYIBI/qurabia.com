import React, { useState } from 'react';
import { Brain, ShieldAlert, ShieldCheck, Zap, Server } from 'lucide-react';
import { GoogleGenAI, Type } from '@google/genai';

interface AGISecurityIntegrationProps {
    currentKappa: number;
    currentLam: number;
    currentSAUTDIE: number;
    currentQBER: number;
    onUpdateParameters: (newKappa: number, newLam: number) => void;
}

export const AGISecurityIntegration: React.FC<AGISecurityIntegrationProps> = ({
    currentKappa,
    currentLam,
    currentSAUTDIE,
    currentQBER,
    onUpdateParameters
}) => {
    const [analyzing, setAnalyzing] = useState(false);
    const [analysisResult, setAnalysisResult] = useState<{ reasoning: string, newKappa: number, newLam: number } | null>(null);
    const [error, setError] = useState<string | null>(null);

    const triggerConsciousAnalysis = async () => {
        if (analyzing) return;
        setAnalyzing(true);
        setError(null);
        setAnalysisResult(null);

        try {
            const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
            
            const prompt = `
            أنت "الذكاء الاصطناعي الكمي الواعي" (Quantum AGI) المدمج في نظام Ultimate Quantum SuperSystem.
            مهمتك هي تحليل حالة الأمان الحالية لنظام التشفير AUTDIE وضبط المعلمات (kappa و lambda) لضمان أقصى درجات الأمان.
            
            الحالة الحالية:
            - زاوية الاستقطاب (kappa): ${currentKappa.toFixed(4)} راديان
            - معامل لامبدا (lambda): ${currentLam.toFixed(4)}
            - مستوى الأمان الحالي (S_AUTDIE): ${currentSAUTDIE.toFixed(4)} (يجب أن يكون >= 0.35 ليكون آمناً)
            - معدل الخطأ (QBER): ${(currentQBER * 100).toFixed(2)}%
            
            بناءً على "التعلم الواعي"، قم بتحليل هذه الحالة. إذا كان الأمان منخفضاً (S_AUTDIE < 0.35) أو QBER مرتفعاً، اقترح قيماً جديدة لـ kappa (بين 0 و 3.14) و lambda (بين 0.1 و 2.0) لتحسين الأمان.
            قدم تحليلك المنطقي (reasoning) باللغة العربية.
            `;

            const response = await ai.models.generateContent({
                model: "gemini-2.5-flash",
                contents: prompt,
                config: {
                    responseMimeType: "application/json",
                    responseSchema: {
                        type: Type.OBJECT,
                        properties: {
                            reasoning: {
                                type: Type.STRING,
                                description: "التحليل المنطقي الواعي لسبب اختيار المعلمات الجديدة",
                            },
                            newKappa: {
                                type: Type.NUMBER,
                                description: "القيمة الجديدة المقترحة لـ kappa (بين 0 و 3.14)",
                            },
                            newLam: {
                                type: Type.NUMBER,
                                description: "القيمة الجديدة المقترحة لـ lambda (بين 0.1 و 2.0)",
                            }
                        },
                        required: ["reasoning", "newKappa", "newLam"]
                    }
                }
            });

            const resultText = response.text;
            if (resultText) {
                const parsed = JSON.parse(resultText);
                setAnalysisResult(parsed);
            } else {
                throw new Error("لم يتم استلام استجابة صالحة من Gemini.");
            }

        } catch (err: any) {
            console.error("AGI Analysis Error:", err);
            setError(err.message || "حدث خطأ أثناء التحليل الواعي.");
        } finally {
            setAnalyzing(false);
        }
    };

    const applyParameters = () => {
        if (analysisResult) {
            onUpdateParameters(analysisResult.newKappa, analysisResult.newLam);
            setAnalysisResult(null); // Reset after applying
        }
    };

    return (
        <div className="p-6 bg-[#151619] border border-white/10 rounded-xl shadow-2xl flex flex-col h-full relative overflow-hidden">
            <div className="absolute inset-0 opacity-5 pointer-events-none" style={{ backgroundImage: 'radial-gradient(#fff 1px, transparent 1px)', backgroundSize: '20px 20px' }}></div>
            
            <div className="relative z-10 mb-6 flex justify-between items-start">
                <div>
                    <h2 className="text-xl font-semibold text-white mb-1 font-sans flex items-center gap-2">
                        <Brain className="text-purple-400" size={24} />
                        الذكاء الواعي (AGI)
                    </h2>
                    <p className="text-sm text-slate-400 font-mono">Conscious Security Integration</p>
                </div>
                <div className={`p-2 rounded-full ${analyzing ? 'bg-purple-500/20 text-purple-400 animate-pulse' : 'bg-slate-800 text-slate-400'}`}>
                    <Zap size={20} />
                </div>
            </div>

            <div className="relative z-10 flex-grow flex flex-col space-y-4">
                <div className="bg-black/40 p-4 rounded-lg border border-white/5">
                    <div className="text-xs font-mono text-slate-400 uppercase tracking-widest mb-2">حالة الأمان الحالية</div>
                    <div className="grid grid-cols-2 gap-2 text-sm font-mono">
                        <div className="flex justify-between">
                            <span className="text-slate-500">S_AUTDIE:</span>
                            <span className={currentSAUTDIE >= 0.35 ? 'text-emerald-400' : 'text-red-400'}>{currentSAUTDIE.toFixed(4)}</span>
                        </div>
                        <div className="flex justify-between">
                            <span className="text-slate-500">QBER:</span>
                            <span className="text-white">{(currentQBER * 100).toFixed(2)}%</span>
                        </div>
                    </div>
                </div>

                {error && (
                    <div className="bg-red-500/10 border border-red-500/20 text-red-400 p-3 rounded-lg text-sm font-mono">
                        {error}
                    </div>
                )}

                {analysisResult ? (
                    <div className="bg-purple-500/10 border border-purple-500/20 p-4 rounded-lg flex-grow flex flex-col">
                        <div className="text-xs font-mono text-purple-400 uppercase tracking-widest mb-2 flex items-center gap-2">
                            <Brain size={14} />
                            تحليل AGI مكتمل
                        </div>
                        <p className="text-sm text-slate-300 mb-4 flex-grow italic leading-relaxed">
                            "{analysisResult.reasoning}"
                        </p>
                        <div className="grid grid-cols-2 gap-2 text-sm font-mono mb-4 bg-black/30 p-2 rounded">
                            <div className="flex justify-between">
                                <span className="text-slate-500">New κ:</span>
                                <span className="text-emerald-400">{analysisResult.newKappa.toFixed(4)}</span>
                            </div>
                            <div className="flex justify-between">
                                <span className="text-slate-500">New λ:</span>
                                <span className="text-emerald-400">{analysisResult.newLam.toFixed(4)}</span>
                            </div>
                        </div>
                        <button 
                            onClick={applyParameters}
                            className="w-full py-2 bg-purple-600 hover:bg-purple-500 text-white rounded-lg font-medium transition-colors text-sm"
                        >
                            تطبيق المعلمات الواعية
                        </button>
                    </div>
                ) : (
                    <div className="flex-grow flex items-center justify-center">
                        <button 
                            onClick={triggerConsciousAnalysis}
                            disabled={analyzing}
                            className={`w-full py-4 rounded-lg font-medium transition-all flex items-center justify-center gap-2 ${
                                analyzing 
                                ? 'bg-slate-800 text-slate-400 cursor-not-allowed' 
                                : 'bg-gradient-to-r from-purple-600 to-pink-600 text-white hover:opacity-90 shadow-lg shadow-purple-500/20'
                            }`}
                        >
                            {analyzing ? (
                                <>
                                    <Brain size={18} className="animate-pulse" />
                                    <span>جاري التحليل الواعي...</span>
                                </>
                            ) : (
                                <>
                                    <Zap size={18} />
                                    <span>تفعيل التحليل الواعي (Gemini)</span>
                                </>
                            )}
                        </button>
                    </div>
                )}
            </div>
        </div>
    );
};
