import React, { useState, useCallback } from 'react';
import { Orbit, Zap, Activity } from 'lucide-react';
import { useToast } from './Toast';

export const AlUtaibiV2Module: React.FC = () => {
    const { showToast } = useToast();
    const [radius, setRadius] = useState<number>(1.616e-35); // Planck length
    const [rhoDm, setRhoDm] = useState<number>(1.8e10);
    const [rhoDe, setRhoDe] = useState<number>(1e-10);
    const [result, setResult] = useState<any>(null);
    const [loading, setLoading] = useState<boolean>(false);

    const runSimulation = useCallback(async () => {
        setLoading(true);
        try {
            const res = await fetch('/api/al-utaibi-v2', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ r: radius, rho_dm: rhoDm, rho_de: rhoDe })
            });
            const data = await res.json();
            setResult(data);
            showToast("تم حساب الطاقة الكونية بنجاح.", "success");
        } catch (e) {
            console.error("Failed to run Al-Utaibi v2.0 simulation", e);
            showToast("فشل الاتصال بمحرك الحساب الكمومي. يرجى المحاولة لاحقاً.", "error");
        } finally {
            setLoading(false);
        }
    }, [radius, rhoDm, rhoDe]);

    return (
        <div className="p-6 bg-transparent h-full flex flex-col relative overflow-hidden">
            <div className="absolute top-0 right-0 w-64 h-64 bg-purple-500/5 rounded-full blur-3xl -mr-20 -mt-20 pointer-events-none"></div>
            
            <div className="mb-6 flex justify-between items-start z-10">
                <div>
                    <h2 className="text-xl font-semibold text-white mb-1 font-sans">التوائم الرقمية للكون</h2>
                    <p className="text-sm text-slate-400 font-mono">معادلة العتيبي الموحدة (Cosmic Physics Unification)</p>
                </div>
                <div className="p-3 rounded-full bg-purple-500/20 text-purple-400">
                    <Orbit size={24} />
                </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 flex-grow z-10">
                <div className="space-y-4">
                    <div className="bg-black/40 p-4 rounded-lg border border-white/5">
                        <label className="block text-xs font-mono text-slate-400 uppercase tracking-wider mb-2">
                            نصف القطر (r) - مقياس بلانك
                        </label>
                        <input 
                            type="number" 
                            value={radius} 
                            onChange={(e) => setRadius(Number(e.target.value))}
                            className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-white font-mono text-sm focus:outline-none focus:border-purple-500"
                            step="1e-36"
                        />
                        <p className="text-[10px] text-slate-500 mt-1 font-mono">Default: 1.616e-35 m</p>
                    </div>

                    <div className="bg-black/40 p-4 rounded-lg border border-white/5">
                        <label className="block text-xs font-mono text-slate-400 uppercase tracking-wider mb-2">
                            كثافة المادة المظلمة (ρ_dm)
                        </label>
                        <input 
                            type="number" 
                            value={rhoDm} 
                            onChange={(e) => setRhoDm(Number(e.target.value))}
                            className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-white font-mono text-sm focus:outline-none focus:border-purple-500"
                        />
                    </div>

                    <button 
                        onClick={runSimulation}
                        disabled={loading}
                        className={`w-full flex items-center justify-center gap-2 py-3 px-4 rounded-lg font-medium transition-all ${
                            loading 
                            ? 'bg-slate-800 text-slate-400 cursor-not-allowed' 
                            : 'bg-gradient-to-r from-purple-600 to-pink-600 text-white hover:opacity-90 shadow-lg shadow-purple-500/20'
                        }`}
                    >
                        {loading ? <Activity size={18} className="animate-spin" /> : <Zap size={18} />}
                        <span>حساب الطاقة الكونية (Deep Backend)</span>
                    </button>
                </div>

                <div className="bg-black/60 rounded-lg border border-white/10 p-4 font-mono text-sm overflow-auto">
                    <div className="text-xs text-slate-500 uppercase tracking-widest mb-3 border-b border-white/10 pb-2">
                        نتائج التوحيد الفيزيائي
                    </div>
                    
                    {result ? (
                        <div className="space-y-3">
                            <div className="flex justify-between items-center">
                                <span className="text-slate-400">الطاقة الأساسية (v1.0):</span>
                                <span className="text-blue-400">{result.E_v1.toExponential(3)} J</span>
                            </div>
                            <div className="flex justify-between items-center">
                                <span className="text-slate-400">محاكاة إشعاع هوكينج:</span>
                                <span className="text-orange-400">نشط (Black Holes)</span>
                            </div>
                            <div className="flex justify-between items-center">
                                <span className="text-slate-400">نمذجة التغير المناخي:</span>
                                <span className="text-emerald-400">دقة فائقة (LQG)</span>
                            </div>
                            <div className="pt-3 mt-3 border-t border-white/10">
                                <div className="text-xs text-slate-500 mb-1">الطاقة الكلية v2.0 (E_TOTAL)</div>
                                <div className="text-2xl text-purple-400 font-bold">{result.E_total.toExponential(3)} J</div>
                                <div className="text-sm text-pink-400 mt-1">{result.eV.toExponential(3)} eV</div>
                            </div>
                            {result.qm_effect < 1.0 && (
                                <div className="mt-4 p-2 bg-emerald-500/10 border border-emerald-500/20 rounded text-emerald-400 text-xs">
                                    [Singularity Suppressed] تم تثبيط الانحناء اللانهائي بنجاح عند مقياس بلانك.
                                </div>
                            )}
                        </div>
                    ) : (
                        <div className="h-full flex items-center justify-center text-slate-600 text-center">
                            اضغط على زر الحساب لتشغيل المحرك الخلفي (Python/Node.js) لمعادلة العتيبي v2.0
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};
